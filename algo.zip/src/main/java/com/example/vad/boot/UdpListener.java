package com.example.vad.boot;


import com.example.vad.Span;
import com.example.vad.SpanDetector;
import com.example.vad.metrics.SpanDetectorMetrics;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.List;

import net.sf.fmj.media.rtp.util.RTPPacket;
import org.json.JSONArray;


@Component
public class UdpListener {

    @Value("${udp.port}")
    private int udpPort;

    private SpanDetector spanDetector;

    @PostConstruct
    public void init() {
        spanDetector = new SpanDetector(16000); // Initialize with sample rate
        new Thread(this::startListening).start();
    }

    public void startListening() {
        try (DatagramSocket socket = new DatagramSocket(udpPort)) {
            byte[] buffer = new byte[2048];
            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                processPacket(packet);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processPacket(DatagramPacket packet) {
        RTPPacket rtpPacket = new RTPPacket();

        // Assuming audio payload is in rtpPacket.data
        double[] audioData = new double[rtpPacket.data.length / 2]; // Assuming 16-bit PCM
        for (int i = 0; i < audioData.length; i++) {
            audioData[i] = (short) ((rtpPacket.data[i * 2] & 0xFF) | (rtpPacket.data[i * 2 + 1] << 8)) / 32768.0;
        }

        List<Span> spans = spanDetector.addToStream(audioData, "speaker1");

        // Convert spans to JSON
        JSONArray spansJson = new JSONArray();
        for (Span span : spans) {
            JSONObject spanJson = new JSONObject();
            spanJson.put("startIdx", span.getStartIdx());
            spanJson.put("endIdx", span.getEndIdx());
            spanJson.put("startDb", span.getStartDb());
            spanJson.put("endDb", span.getEndDb());
            spanJson.put("numVoiceChunks", span.getNumVoiceChunks());
            spanJson.put("numNonVoiceChunks", span.getNumNonVoiceChunks());
            spanJson.put("speaker", span.getSpeaker());
            spansJson.put(spanJson);
        }

        // Save results to file
        SpanDetectorMetrics.saveResults("results.json", new JSONArray(), spansJson);
    }
}
