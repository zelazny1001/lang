package com.example.vad.boot;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class VadApplication {

    public static void main(String[] args) {
        int udpPort = 5000;
        int serverPort = 9500;

        Map<String, Object> properties = new HashMap<>();
        properties.put("udp.port", udpPort);
        properties.put("server.port", serverPort);
        properties.put("spring.banner.location", "classpath:vad-banner.txt");

        new SpringApplicationBuilder(VadApplication.class)
                .properties(properties)
                .run(args);
    }
}
