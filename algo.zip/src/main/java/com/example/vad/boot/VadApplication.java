package com.example.vad.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VadApplication {

    public static void main(String[] args) {
        SpringApplication.run(VadApplication.class, args);
    }
}
