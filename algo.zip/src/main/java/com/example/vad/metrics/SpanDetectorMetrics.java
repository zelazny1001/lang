package com.example.vad.metrics;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

public class SpanDetectorMetrics {

    public void saveResults(String filename, JSONArray spansJson) {
        JSONObject results = new JSONObject();
        results.put("spans", spansJson);

        try (FileWriter file = new FileWriter(filename, true)) { // append spans to file
            file.write(results.toString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public float[] loadDataFromFile(String filename) throws IOException {
        byte[] byteArray = Files.readAllBytes(Paths.get(filename));
        float[] audioData = new float[byteArray.length / 8];
        for (int i = 0; i < audioData.length; i++) {
            audioData[i] = ByteBuffer.wrap(byteArray, i * 8, 8).getFloat();
        }
        return audioData;
    }
}