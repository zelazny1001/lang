package com.example.vad;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.complex.Complex;
import org.apache.commons.math3.transform.DftNormalization;
import org.apache.commons.math3.transform.FastFourierTransformer;
import org.apache.commons.math3.transform.TransformType;

public class SpanDetector {
    private int sr;
    private int currIdx;
    private Candidate currCandidate;
    private List<Span> spans;
    private double backgroundEnergyTimeout;
    private boolean backgroundEnergyInitialized;
    private double backgroundEnergy;
    private double dbOffset;
    private double minSoFar;

    public SpanDetector(int sr) {
        this.sr = sr;
        this.currIdx = 0;
        this.currCandidate = null;
        this.spans = new ArrayList<>();
        this.backgroundEnergyTimeout = 2.0;
        this.backgroundEnergyInitialized = false;
        this.backgroundEnergy = 0.0;
        this.dbOffset = 2.5;
        this.minSoFar = Double.POSITIVE_INFINITY;
    }

    public List<Span> addToStream(double[] audio, String speaker) {
        int nSamples = audio.length;
        double secondsPerFrame = 20e-3;
        int samplesPerFrame = (int) (secondsPerFrame * sr);
        List<Span> spans = new ArrayList<>();

        for (int i = 0; i < nSamples - 1; i += samplesPerFrame) {
            int start = i + currIdx;
            int end = start + samplesPerFrame;
            double[] audioB = new double[samplesPerFrame];
            System.arraycopy(audio, i, audioB, 0, samplesPerFrame);

            double frameEnergy = calculateFrameEnergy(audioB);

            if (frameEnergy < minSoFar) {
                minSoFar = frameEnergy;
            }

            if ((double) currIdx / sr < backgroundEnergyTimeout) {
                if (!backgroundEnergyInitialized) {
                    backgroundEnergy = frameEnergy;
                    backgroundEnergyInitialized = true;
                } else {
                    backgroundEnergy += (frameEnergy - backgroundEnergy) / (end / samplesPerFrame);
                }
                continue;
            }

            double offset = Math.log10(frameEnergy / backgroundEnergy);
            if (offset < 0) {
                backgroundEnergy = (0.1 * backgroundEnergy + 0.9 * frameEnergy);
            } else if (offset > dbOffset) {
                backgroundEnergy = (0.90 * backgroundEnergy + 0.10 * frameEnergy);
                if (currCandidate == null) {
                    currCandidate = new Candidate(start, frameEnergy);
                }
                Span span = new Span(currCandidate.getStartIdx(), end, currCandidate.getStartDb(), frameEnergy,
                        currCandidate.getNumVoiceChunks(), currCandidate.getNumNonVoiceChunks(), speaker);
                spans.add(span);
                this.spans.add(span);

                currCandidate = null;
            }
        }
        currIdx += nSamples;
        return spans;
    }

    private double calculateFrameEnergy(double[] audioB) {
        int N = audioB.length;
        double[] windowedAudio = applyHammingWindow(audioB);
        double[] fftResult = calculateFFT(windowedAudio);
        double sum = 0.0;
        for (double v : fftResult) {
            sum += Math.abs(v) * Math.abs(v);
        }
        return sum / N;
    }

    private double[] applyHammingWindow(double[] audio) {
        int N = audio.length;
        double[] windowedAudio = new double[N];
        for (int i = 0; i < N; i++) {
            windowedAudio[i] = audio[i] * (0.54 - 0.46 * Math.cos(2 * Math.PI * i / (N - 1)));
        }
        return windowedAudio;
    }

    private double[] calculateFFT(double[] audio) {
        FastFourierTransformer transformer = new FastFourierTransformer(DftNormalization.UNITARY);
        Complex[] complexResult = transformer.transform(audio, TransformType.FORWARD);
        double[] result = new double[complexResult.length];
        for (int i = 0; i < complexResult.length; i++) {
            result[i] = complexResult[i].abs();
        }
        return result;
    }
}