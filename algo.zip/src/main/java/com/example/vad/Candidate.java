package com.example.vad;

public class Candidate {
    private int startIdx;
    private float startDb;
    private int numVoiceChunks;
    private int numNonVoiceChunks;

    public Candidate(int startIdx, float startDb) {
        this.startIdx = startIdx;
        this.startDb = startDb;
        this.numVoiceChunks = 0;
        this.numNonVoiceChunks = 0;
    }

    public void addVoice() {
        numVoiceChunks++;
    }

    public void addNonVoice() {
        numNonVoiceChunks++;
    }

    public int getStartIdx() {
        return startIdx;
    }

    public float getStartDb() {
        return startDb;
    }

    public int getNumVoiceChunks() {
        return numVoiceChunks;
    }

    public int getNumNonVoiceChunks() {
        return numNonVoiceChunks;
    }
}